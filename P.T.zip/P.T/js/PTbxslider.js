$(function(){
		$(".PTslider .PTbox:nth-child(1)").attr("src",$(".main a:nth-child(1) .PTbox").attr("src"))
										.attr("alt",$(".main a:nth-child(1) .PTbox").attr("alt"));
		$(".PTslider .PTbox:nth-child(2)").attr("src",$(".main a:nth-child(2) .PTbox").attr("src"))
										.attr("alt",$(".main a:nth-child(2) .PTbox").attr("alt"));
		$(".PTslider .PTbox:nth-child(3)").attr("src",$(".main a:nth-child(3) .PTbox").attr("src"))
										.attr("alt",$(".main a:nth-child(3) .PTbox").attr("alt"));
		$(".PTslider .PTbox:nth-child(4)").attr("src",$(".main a:nth-child(4) .PTbox").attr("src"))
										.attr("alt",$(".main a:nth-child(4) .PTbox").attr("alt"));
				});

$(document).ready(function(){
  $('.PTslider').bxSlider({
  auto: true,
  pause: 4000,
  speed: 1000,
  //一度に表示させる最大枚数
  maxSlides: 1,
  //タッチスワイプ許可設定
  touchEnabled: true,
  //タッチスワイプしたとみなす最低限の移動距離
  swipeThreshold: 10,
  //'full'はスライダーの数を黒点で、'short'はa/nで表示
  pagerType: 'full',
  // 画像の高さを自動調整
  adaptiveHeight: true,
  //コントロール表示
  controls: false,
  //スライドモード設定
  mode: 'fade',
  //スライド番号を表示する
  pager: false
  });
});